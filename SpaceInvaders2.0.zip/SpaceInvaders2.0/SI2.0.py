import random
import pygame
import math

f = open("HighScore2.txt",'r+')
highestscore=int(f.read())
f.seek(0)
flag=0

pygame.init()

background = pygame.image.load('SpaceBackground.png')

screen = pygame.display.set_mode((800, 600))

pygame.display.set_caption("Space Invaders")
icon = pygame.image.load('spaceship.png')
pygame.display.set_icon(icon)

playerimg = pygame.image.load('player2.png')
playerspeed = 5
playerX = 350
playerY = 480
PchangeX = 0
PchangeY = 0

enemyimg = []
enemyX = []
enemyY = []
enemyspeed = 4
EchangeX = []
EchangeY = []
numberofenemies=5

enemyimg.append(pygame.image.load('purple.png'))
enemyimg.append(pygame.image.load('green.png'))
enemyimg.append(pygame.image.load('orange.png'))
enemyimg.append(pygame.image.load('red.png'))
enemyimg.append(pygame.image.load('blue.png'))

for i in range(numberofenemies):

    enemyX.append(random.randint(0, 735))
    enemyY.append(random.randint(0, 150))
    EchangeX.append(enemyspeed)
    EchangeY.append(40)

# ready - you cant see the bullet
# fire - the bullet is current moving
bulletimg = pygame.image.load('bullet.png')
bulletX = 0
bulletY = 480
BchangeX = 0
BchangeY = 10
bullet_state = "ready"

score = 0
font = pygame.font.Font('freesansbold.ttf', 32)
textX = 10
textY = 10

over_font = pygame.font.Font('freesansbold.ttf', 60)

cfont= pygame.font.Font('freesansbold.ttf', 14)

hsfont= pygame.font.Font('freesansbold.ttf', 20)

def showscore(x, y):
    score_value = font.render("Score : " + str(score), True, (255, 255, 255))
    screen.blit(score_value, (x, y))

def highscore():
    hs_value=hsfont.render("Highest Score : "+str(highestscore),True,(255,255,255))
    screen.blit(hs_value,(615,10))

def gameover():
    overtext = over_font.render("GAME OVER", True, (255, 0, 0))
    screen.blit(overtext, (200, 250))
    global score, highestscore,flag
    if score > highestscore:
        highestscore = score
        f.write(str(highestscore))
        flag=1



def player(x, y):
    screen.blit(playerimg, (x, y))


def enemy(x, y, i):
    screen.blit(enemyimg[i], (x, y))


def creator():
    creator = cfont.render("By Shrutik Gumate",True, (255, 255, 255))
    screen.blit(creator,(650,560))

def congrats():
    congrats = font.render("Congratulations you are the Top Scorer!!!", True, (255, 255, 255))
    screen.blit(congrats, (50, 350))

def fire_bullet(x, y):
    global bullet_state
    bullet_state = "fire"
    screen.blit(bulletimg, (x + 16, y + 10))


def isCollision(enemyX, enemyY, bulletX, bulletY):
    distance = math.sqrt(math.pow((enemyX - bulletX), 2) + math.pow((enemyY - bulletY), 2))
    if distance < 25: return True
    return False


running = True
while running:

    screen.fill((0, 0, 0))
    screen.blit(background, (0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                PchangeX -= playerspeed

            if event.key == pygame.K_RIGHT:
                PchangeX += playerspeed

            if event.key == pygame.K_SPACE:
                if bullet_state == "ready":
                    bulletX = playerX
                    fire_bullet(bulletX, bulletY)

        if event.type == pygame.KEYUP:
            # checks whether its that key or not
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT or event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                PchangeX = 0
                PchangeY = 0

    playerX += PchangeX

    if playerX <= 0:
        playerX = 0
    elif playerX >= 736:
        playerX = 736

    for i in range(numberofenemies):

        enemyX[i] += EchangeX[i]

        if enemyX[i] <= 0:
            EchangeX[i] = 4
            enemyY[i] += EchangeY[i]
        elif enemyX[i] >= 768:
            EchangeX[i] = -4
            enemyY[i] += EchangeY[i]
        if enemyY[i] > 460:
            enemyY[i] = 2000
            gameover()
            break

        collision = isCollision(enemyX[i], enemyY[i], bulletX, bulletY)
        if collision:
            bullet_state = "ready"
            bulletY = 480
            score += 1
            #enemyspeed[i] += 1
            print(score)
            enemyX[i] = random.randint(0, 768)
            enemyY[i] = random.randint(0, 150)

        enemy(enemyX[i], enemyY[i],i)

    if bulletY <= 0:
        bulletY = playerY
        bullet_state = "ready"

    if bullet_state == "fire":
        fire_bullet(bulletX, bulletY)
        bulletY -= BchangeY

    player(playerX, playerY)
    showscore(textX, textY)
    highscore()
    if flag==1:
        congrats()
    creator()

    pygame.display.update()

f.close()